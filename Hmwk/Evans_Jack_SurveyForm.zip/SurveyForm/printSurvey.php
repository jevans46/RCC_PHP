<html>
 <?php /*
 	RCC Class PHP
	Sept 15th, 2015
	Purpose:  simple form
	   */
 ?>
 <body>     
    <p>Your favorite type of movie is: <?php echo $_POST["movie"];?></p>
    <p>Your favorite color is: <?php echo $_POST["color"];?></p>
    <p>Your favorite type of car is: <?php echo $_POST["car"];?></p>
 </body>
</html>